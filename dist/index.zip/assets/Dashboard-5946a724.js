import{_ as a}from"./PackingLayout-3c14fa63.js";import{d as r,e}from"./index-c1909b7c.js";const m={__name:"Dashboard",setup(o){return(t,s)=>(r(),e(a,{title:"Dashboard"}))}};export{m as default};
